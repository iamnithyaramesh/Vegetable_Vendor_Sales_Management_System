Vegetable Vendor Application

Run the main.py file.

If you want to login as the vendor, use these login credentials:
    username: Vendor
    password: Vendor123
NOTE: You can change the username and password using Change details in the vendor menu after logging in!

Make sure you close the terminal or exit in order to save your changes.