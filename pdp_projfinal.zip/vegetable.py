from exceptions import *

def validate_price(func):
    """Decorator to validate the price input."""
    def wrapper1(self, new_price):
        if new_price > 0 and isinstance(new_price, (int, float)):
            return func(self, new_price)
        else:
            raise InvalidPrice('Enter a valid price.')
    return wrapper1

def validate_stock(func):
    """Decorator to validate the stock quantity input."""
    def wrapper2(self, qty):
        if isinstance(qty, int):
            return func(self, qty)
        else:
            raise InvalidQuantity('Enter a valid quantity.')
    return wrapper2

class Vegetable:
    def __init__(self, name=None, category=None, price=None, stock=None):
        """Initialize a Vegetable object with name, category, price, and stock."""
        self._name = name
        self._category = category
        self._price = price
        self._stock = stock

    @property
    def price(self):
        """Getter method for the price attribute."""
        return self._price

    @price.setter
    @validate_price
    def price(self, new_price):
        """Setter method for the price attribute with price validation."""
        self._price = new_price

    @property
    def stock(self):
        """Getter method for the stock attribute."""
        return self._stock
    
    @stock.setter
    @validate_stock
    def stock(self, qty):
        """Setter method for the stock attribute with quantity validation."""
        self._stock = qty

if __name__ == '__main__':
    try:
        carrot = Vegetable(name="Carrot", category="Root", price=1.5, stock=100)

        # Display the initial details
        print(f"Vegetable: {carrot._name}")
        print(f"Category: {carrot._category}")
        print(f"Price: {carrot.price}")
        print(f"Stock: {carrot.stock}")

        # Update the price and stock
        carrot.price = 5
        print(f"Price: {carrot.price}")

        # Uncommenting the line below will raise an InvalidPrice exception
        # carrot.price = -2

        carrot.stock = 20
        print(f"Stock: {carrot.stock}")

        # Uncommenting the line below will raise an InvalidQuantity exception
        # carrot.stock = 'ghwi'

    except (InvalidPrice, InvalidQuantity) as e:
        print(f"Error: {e}")
