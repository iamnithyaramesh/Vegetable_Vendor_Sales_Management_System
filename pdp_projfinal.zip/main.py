import pickle
import datetime
import re

from vegetable import *
from inventory import *
from customer import *
from cart import *
from vendor import *
from email_notification import *

def validate_password(password):
    """
    Validate the format of a password.

    Parameters:
    - password (str): Password to be validated.

    Returns:
    - bool: True if the password is valid, False otherwise.

    """
    if password is None:
        return False

    pattern = r"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
    match = re.match(pattern, password)
    return bool(match)

class InvalidInput(Exception):
    pass

class InvalidLoginCredentials(Exception):
    pass

class UserUnavailable(Exception):
    pass

class VegetableVendorApplication:

    _instance = None

    def __new__(cls):
        if not cls._instance:
            cls._instance = super(VegetableVendorApplication, cls).__new__(cls)
        return cls._instance

    def __init__(self, name=None, vendor=None):
        """
        Vegetable Vendor Application class.

        Parameters:
        - name (str): Name of the application.
        - vendor (Vendor): Vendor associated with the application.

        """
        self.inventory = Inventory()
        self.users = []
        self.vendor = vendor
        self.name = name
        self.c_user = None

    def set_name(self, name):
        """
        Set the name of the application.

        Parameters:
        - name (str): Name of the application.

        """
        self.name = name

    def add_vendor(self, vendor):
        """
        Add a vendor to the application.

        Parameters:
        - vendor (Vendor): Vendor to be added.

        """
        self.vendor = vendor

    def register_user(self):
        """
        Register a new user.

        """
        while True:
            username = input("Enter your username: ")
            if username != '':
                if username not in [user.name for user in self.users]:
                    break
                else:
                    print('Username already exists. Please use another username.')
            else:
                print('Enter a valid username.')

        address = input("Enter your address: ")
        while True:
            email = input('Enter your email address: ')
            if email != '':
                if validate_email1(email) or validate_email2(email):
                    break
                else:
                    print('E-mail is invalid. Please use a valid e-mail.')

        while True:
            password = input("Enter your password [Must contain at least one uppercase letter, one number, and one symbol]: ")
            if password != '':
                if validate_password(password) == False:
                    print("Re-enter your password.")
                else:
                    break
            else:
                print('Enter a valid password.')

        user = Customer(username, email, address, password)
        self.users.append(user)
        print('Account registered successfully.')

    def login_user(self, username, password):
        """
        Login a user.

        Parameters:
        - username (str): Username of the user.
        - password (str): Password of the user.

        Returns:
        - User: Logged-in user.

        Raises:
        - InvalidLoginCredentials: If the login credentials are invalid.

        """
        for user in self.users:
            if user.name == username and user.password == password:
                print('Logged in successfully.')
                self.c_user = user
                return user
        if self.vendor.name == username and self.vendor.password == password:
            return self.vendor
        raise InvalidLoginCredentials('Invalid login credentials!')

    def place_order(self):
        """
        Place an order.

        """
        self.inventory.display_items(self.inventory._items_available)
        cart = self.c_user.place_order(self.c_user, self.inventory._items_available)
        if cart:
            self.vendor.add_order(cart)

    def process_customer_order(self):
        """
        Process a customer order.

        """
        details = self.vendor.process_order()
        print(details)
        if details:
            payment_notification(details[0], details[1], self.name, details[2], details[3])


def dump(obj, file):
    """
    Dump an object to a file using pickle.

    Parameters:
    - obj: Object to be dumped.
    - file (str): File name.

    """
    with open(file, 'wb') as f:
        pickle.dump(obj, f)


def load(file):
    """
    Load an object from a file using pickle.

    Parameters:
    - file (str): File name.

    Returns:
    - obj: Loaded object.

    """
    with open(file, 'rb') as f:
        obj = pickle.load(f)
        if obj:
            return obj
        else:
            new_obj = VegetableVendorApplication()

def main_menu():
    """
    Main menu of the application.

    """
    app = load('vegie_app.pkl')

    print(f'Welcome to {app.name}')
    while True:
        try:
            option = int(input('1) Login \n2) Register\n3) Exit\nEnter your choice (1-3): '))

            if option == 1:
                try:
                    username = input('Enter your username: ')
                    password = input('Enter your password: ')
                    c = app.login_user(username, password)

                except InvalidLoginCredentials as e:
                    print(e)

                else:
                    print('User logged in successfully!\n')
                    dump(app, 'vegie_app.pkl')
                    if type(c).__name__ == 'Customer':
                        customer_menu(app)
                    elif type(c).__name__ == 'Vendor':
                        vendor_menu(app)

            elif option == 2:
                while True:
                    try:
                        app.register_user()
                    except InvalidLoginCredentials as e:
                        print(e)
                    else:
                        dump(app, 'vegie_app.pkl')
                        main_menu()

            elif option == 3:
                print("Exiting the application.")
                dump(app, 'vegie_app.pkl')
                return None

        except ValueError as e:
            print('Enter a valid number (1/2/3).')

def vendor_menu(app):
    """
    Vendor menu of the application.

    Parameters:
    - app (VegetableVendorApplication): Application instance.

    """
    options = {
        '1': app.vendor.view_orders,
        '2': app.inventory.display_items,  # Removed the function call
        '3': app.inventory.display_items,
        '4': app.vendor.change_inventory,
        '5': app.vendor.update_picks,
        '6': app.vendor.remove_picks,
        '7': app.process_customer_order,
        '8': app.set_name,
        '9': app.vendor.change_details,
        '10': main_menu
    }

    while True:
        print("\nVendor Menu:")
        print("\n1. View Orders")
        print("2. View all vegetables")
        print("3. View today's picks")
        print("4. Update/Add vegetable")
        print("5. Update today's picks")
        print("6. Remove from today's picks")
        print("7. Process Order")
        print("8. Change shop name")
        print("9. Change details")
        print("10. Exit")

        choice = input("Enter your choice (1-10): ")
        print()

        if choice in options:
            chosen_option = options[choice]

            if callable(chosen_option):
                if choice == '2':
                    chosen_option(app.inventory._all_items)
                    print()
                elif choice == '3':
                    chosen_option(app.inventory._items_available)
                    print()
                elif choice == '8':
                    shop_name = input('Enter the name of your shop: ')
                    chosen_option(shop_name)
                    print()
                else:
                    chosen_option()
                    print()
                dump(app, 'vegie_app.pkl')
            else:
                print("Invalid choice. Please enter a valid option.")
        else:
            print("Invalid choice. Please enter a valid option.")

def customer_menu(app):
    """
    Customer menu of the application.

    Parameters:
    - app (VegetableVendorApplication): Application instance.

    """
    while True:
        print("\nCustomer Menu:")
        print("1. Display Available Items")
        print("2. Place Order")
        print("3. View Order History")
        print("4. Change Customer Details")
        print("5. Logout")

        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            app.inventory.display_items(app.inventory._items_available)
            dump(app, 'vegie_app.pkl')
            print()
        elif choice == '2':
            cart = app.place_order()
            print()
            dump(app, 'vegie_app.pkl')
        elif choice == '3':
            app.c_user.view_order_history()
            dump(app, 'vegie_app.pkl')
            print()
        elif choice == '4':
            app.c_user.change_details()
            print()
            dump(app, 'vegie_app.pkl')
        elif choice == '5':
            dump(app, 'vegie_app.pkl')
            print("Logging out.")
            return main_menu()
        else:
            print("Invalid choice. Please enter a number between 1 and 5.")

main_menu()

'''app = load('vegie_app.pkl')
app.users = []
dump(app, 'vegie_app.pkl')
'''
'''vendor = Vendor('NitinStaines', 'nitin4236', 'nitinstaines4@gmail.com', Inventory())
app = VegetableVendorApplication()
app.add_vendor(vendor)
dump(app, 'vegie_app.pkl')'''
