import smtplib
from email.message import EmailMessage
from datetime import datetime

def payment_notification(recipient_email, recipient_name, company_name, delivery_time, amount):
    """
    Sends a payment confirmation email to the recipient.

    Parameters:
    - recipient_email: str, the email address of the recipient.
    - recipient_name: str, the name of the recipient.
    - company_name: str, the name of the company sending the notification.
    - delivery_time: str, the expected delivery time.
    - amount: float, the payment amount.

    Returns:
    - None
    """
    sender_email = "padmapriya.chakravarthy@gmail.com"
    sender_key = "ybef liil sskw aswc"

    subject = "Payment Confirmation"
    content = (
        f"Hello {recipient_name},\n\n"
        f"This email is to confirm that a payment of rupees {amount:.2f} has been successfully processed on {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        f"Expected delivery time: {delivery_time}"
        "\n\n"
        "Sincerely,\n"
        f"{company_name}"
    )

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender_email
    msg["To"] = recipient_email
    msg.set_content(content)

    server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    server.login(sender_email, sender_key)
    server.send_message(msg)
    server.quit()

# Example usage for vendor confirmation:
if __name__ == '__main__':
    vendor_email = "padmapriya2210328@ssn.edu.in"
    vendor_name = "Vendor Name"
    amount = 500.00  # Replace with the actual payment amount
    expected_delivery_time = 'efineif'  # Replace with the actual delivery time

    payment_notification(vendor_email, vendor_name, 'manga', expected_delivery_time, amount)

    # Example usage for customer confirmation:
    customer_email = "padmapriya2210328@ssn.edu.in"
    customer_name = "Customer Name"
    amount = 500.00  # Replace with the actual payment amount
    expected_delivery_time = 'efineif'  # Replace with the actual delivery time

    payment_notification(customer_email, customer_name, 'manga', expected_delivery_time, amount)
