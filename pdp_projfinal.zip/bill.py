import tabulate as tb

class Bill:
    def __init__(self, cart=None):
        """
        Constructor for the Bill class.

        Parameters:
        - cart: Cart object, representing the shopping cart containing items to be billed.
        """
        self.cart = cart
        self.items = cart.cart

    def calc_price(self):
        """
        Calculates the total price of items in the cart based on their quantity and price.

        Returns:
        - float: Total price of items in the cart.
        """
        total_price = 0
        for item, qty in self.items.items():
            if item._category == 'Vegetable':
                total_price += qty / 100 * item._price
            else:
                total_price += qty * item._price
        return total_price

    def create_receipt(self):
        """
        Creates a receipt table with item details and total amount.

        Returns:
        - list: List of strings representing the receipt table.
        """
        if not self.items:
            return ["No items in the cart."]

        receipt = []
        total_amount = 0

        # Headers for the table
        headers = ["Name", "Quantity", "Price Per 100g/Bunch", "Total Price"]

        # Data for the table
        table_data = []

        for item, quantity in self.items.items():
            if item._category == 'Vegetable':
                item_price = item.price * quantity / 100
            else:
                item_price = item.price * quantity
            total_amount += item_price
            item_info = [item._name, quantity, item.price, item_price]
            table_data.append(item_info)

        # Adding the total amount to the table
        total_row = ["Total Amount", "", "", total_amount]
        table_data.append(total_row)

        # Format the receipt table using tabulate
        receipt.append(f'Order number: {self.cart.order_no}')
        receipt.append(tb.tabulate(table_data, headers=headers, tablefmt="grid"))
        return receipt

if __name__ == "__main__":
    # Creating instances of Vegetable
    from vegetable import Vegetable
    carrot = Vegetable(name="Carrot", price=1.50, stock=5)
    tomato = Vegetable(name="Tomato", price=2.00, stock=8)
    broccoli = Vegetable(name="Broccoli", price=3.00, stock=6)
    spinach = Vegetable(name="Spinach", price=1.75, stock=9)
    onion = Vegetable(name="Onion", price=1.25, stock=7)

    # Creating a Bill instance
    bill = Bill()

    # Adding vegetables to the bill with quantities less than 10
    bill.items = {carrot: 3, tomato: 5, broccoli: 2, spinach: 4, onion: 3}
    # Calculating the total bill amount
    total_amount = bill.calc_price()

    # Creating and printing the receipt
    receipt = bill.create_receipt()
    for line in receipt:
        print(line)
