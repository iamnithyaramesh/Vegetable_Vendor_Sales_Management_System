from vegetable import Vegetable
from exceptions import *
from datetime import datetime, timedelta
from typing import Iterable, Iterator
from tabulate import *
from pickle import *

class ItemIterable(Iterable):
    def __init__(self, item_list):
        """
        An iterable class for items.

        Parameters:
        - item_list (list): List of items.

        """
        self._item_list = item_list

    def __iter__(self) -> Iterator:
        return ItemIterator(self._item_list)
    

class ItemIterator(Iterator):
    def __init__(self, item_list):
        """
        An iterator class for items.

        Parameters:
        - item_list (list): List of items.

        """
        self._items = [(item._name, item._price, item._stock) for item in item_list]
        self._index = 0

    def __next__(self):
        if self._index == len(self._items):
            raise StopIteration()
        
        item = self._items[self._index]
        self._index += 1
        return item

class Inventory:

    _instance = None

    def __new__(cls):
        if not cls._instance:
            cls._instance = super(Inventory, cls).__new__(cls)
            cls._instance._all_items = []
            cls._instance._items_available = []
        return cls._instance

    def view_all_items(self):
        """
        View all items in the inventory.

        Returns:
        - list: List of all items in the inventory.

        """
        iterable = ItemIterable(self._all_items)
        return list(iterable)

    def add_item(self, item):
        """
        Add an item to the inventory.

        Parameters:
        - item (Vegetable): Item to be added.

        Raises:
        - ItemAlreadyExists: If the item already exists in the inventory.

        """
        if item._name.lower() not in [items._name.lower() for items in self._all_items]:
            self._all_items.append(item)
        else:
            raise ItemAlreadyExists("The item already exists in the inventory.")
        
    def update_item(self, item):
        """
        Update information of an item in the inventory.

        Parameters:
        - item (str): Name of the item to be updated.

        Raises:
        - ItemNotFound: If the item is not found in the inventory.

        Returns:
        - Vegetable: Updated item.

        """
        item_address = self.find_item_address(item)
        if item_address:
            print('Vegetable found. Now edit the details of the vegetable.\n')
            try:
                item_address._name = input('Enter the name of the vegetable: ').title()
                while True:
                    try:
                        category = int(input('Enter the type of the vegetable (1 for Vegetable/2 for Greens): '))
                        if category == 1:
                            item_address._category = 'Vegetable'
                            break
                        elif category == 2:
                            item_address._category = 'Greens'
                            break
                        else:
                            print('Enter a valid input.')
                    except ValueError as e:
                        print('Enter either 1 or 2.')
                item_address._price = float(input('Enter the price of the item (Per 100g/Per bunch): '))
                item_address._stock = int(input('Enter the stock available for the item in grams [1 kilogram = 1000 grams]: '))
                return item_address
            except ValueError:
                print('Enter valid inputs only.')
                return None
        else:
            print('Vegetable not found. Adding a new vegetable, so please enter the details below.\n')
            name = input('Enter the name of the vegetable: ').title()
            try:
                while True:
                    category = input('Enter the type of the vegetable (1 for Vegetable/2 for Greens): ')
                    if category == '1':
                        category = 'Vegetable'
                        break
                    elif category == '2':
                        category = 'Greens'
                        break
                    else:
                        print('Enter a valid input.')
            except ValueError as e:
                print('Enter either 1 or 2.')
            while True:
                try:
                    price = float(input('Enter the price of the item (Per 100g/Per bunch): '))
                    stock = int(input('Enter the stock available for the item in grams [1 kilogram = 1000 grams]: '))
                except ValueError:
                    print('Enter a valid numerical value!')
                else:
                    break
            item = Vegetable(name, category, price, stock)
            self._all_items.append(item)

    def update_today_picks(self, item):
        """
        Update today's picks in the inventory.

        Parameters:
        - item (str): Name of the item to be updated.

        Raises:
        - ItemNotFound: If the item is not found in the inventory.

        """
        for i in self._all_items:
            if item.lower() == i._name.lower():
                self._items_available.append(i)
                print('The vegetable has been added!')
                break 
        else:
            raise ItemNotFound("Vegetable not found. Please retry.")

    def remove_todays_picks(self, item):
        """
        Remove today's picks from the inventory.

        Parameters:
        - item (str): Name of the item to be removed.

        Raises:
        - ItemNotFound: If the item is not found in today's picks.

        """
        for i in self._items_available:
            if item.lower() == i._name.lower():
                self._items_available.remove(i)
                print('The vegetable has been removed!')
                break 
        else:
            raise ItemNotFound("Vegetable not found. Please retry.")  
    
    def view_available_items(self):
        """
        View available items for today.

        Returns:
        - list: List of available items for today.

        """
        iterable = ItemIterable(self._items_available)
        return list(iterable)
    
    def find_item_address(self, name):
        """
        Find the address of an item based on its name.

        Parameters:
        - name (str): Name of the item.

        Returns:
        - Vegetable or None: Address of the item if found, None otherwise.

        """
        if self._all_items:
            for item in self._all_items:
                if item._name.lower() == name.lower():
                    return item
            return None

    def display_items(self, items):
        """
        Display a table of items.

        Parameters:
        - items (list): List of items to be displayed.

        """
        if not items:
            print("No items available.")
            return

        headers = ["S.No.", "Name", "Price", "Quantity"]
        table_data = [(i + 1, item._name, item._price, item._stock) for i, item in enumerate(items)]

        print(tabulate(table_data, headers=headers, tablefmt="grid"))

if __name__ == "__main__":
    # Create items
    item1 = Vegetable("Carrot", "Vegetable", 1.5, 100)
    item2 = Vegetable("Broccoli", "Vegetable", 2.0, 50)
    item3 = Vegetable("Spinach", "Greens", 1.0, 75)

    # Create an inventory
    inventory = Inventory()

    # Add items to the inventory
    try:
        inventory.add_item(item1)
        inventory.add_item(item2)
        print("Items added to the inventory.")
    except ItemAlreadyExists as e:
        print(f"Error: {e}")

    # View all items in the inventory
    all_items = inventory.view_all_items()
    print("\nAll items in the inventory:")
    # inventory.display_items(all_items)

    # Update item information
    try:
        inventory.update_item("Carrot")
        print("\nItem information updated.")
    except ItemNotFound as e:
        print(f"Error: {e}")

    # View updated item list
    all_items = inventory.view_all_items()
    print("\nUpdated items in the inventory:")
    # inventory.display_items(all_items)

    # Try to update today's picks (assuming 'Spinach' is picked today)
    try:
        inventory.update_today_picks('carrot')
        print("\nToday's picks updated.")
    except ItemNotFound as e:
        print(f"Error: {e}")

    # View available items
    available_items = inventory.view_available_items()
    print("\nAvailable items for today:")
    # inventory.display_items(available_items)

    # Update item information again
    try:
        inventory.update_item("Carrot")
        print("\nItem information updated.")
    except ItemNotFound as e:
        print(f"Error: {e}")

    available_items = inventory.view_available_items()
    print("\nAvailable items for today:")
    inventory.display_items(available_items)

    print(inventory._all_items)
