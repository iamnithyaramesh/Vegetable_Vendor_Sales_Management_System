import re
import smtplib
from email.message import EmailMessage
from datetime import datetime

def payment_notification(recipient_email, recipient_name, company_name, time):
    """
    Sends a payment confirmation email to the recipient.

    Parameters:
    - recipient_email (str): Email address of the recipient.
    - recipient_name (str): Name of the recipient.
    - company_name (str): Name of the company sending the email.
    - time (str): Expected delivery time.

    Returns:
    - None
    """
    user = "nitinstaines4@gmail.com"
    key = "dzrs vyvs wtqd tlve"

    subject = "Payment Confirmation"
    content = (
        f"Hello {recipient_name},\n\n"
        f"This email is to confirm that a payment has been successfully processed on {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        f"Expected delivery time: {time}"
        "\n\n"
        "Sincerely,\n"
        f"{company_name}"
    )

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = recipient_email
    msg.set_content(content)

    server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    server.login(user, key)
    server.send_message(msg)
    server.quit()

def validate_password(password):
    """
    Validates the password against a specific pattern.

    Parameters:
    - password (str): Password to be validated.

    Returns:
    - bool: True if the password is valid, False otherwise.
    """
    pattern = r"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
    match = re.match(pattern, password)
    return bool(match)

def validate_upi(upi):
    """
    Validates the UPI (Unified Payments Interface) ID against a specific pattern.

    Parameters:
    - upi (str): UPI ID to be validated.

    Returns:
    - bool: True if the UPI ID is valid, False otherwise.
    """
    if upi is None:
        return False
    pattern = r"^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$"
    match = re.match(pattern, upi)
    return bool(match)

def validate_email1(email):
    """
    Validates the email address against a specific pattern.

    Parameters:
    - email (str): Email address to be validated.

    Returns:
    - bool: True if the email address is valid, False otherwise.
    """
    if email is None:
        return False
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    match = re.match(pattern, email)
    return bool(match)

def validate_email2(email):
    """
    Validates the email address against a specific pattern.

    Parameters:
    - email (str): Email address to be validated.

    Returns:
    - bool: True if the email address is valid, False otherwise.
    """
    if email is None:
        return False
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9.-]+\.[a-zA-Z0-9.-]+$"
    match = re.match(pattern, email)
    return bool(match)
