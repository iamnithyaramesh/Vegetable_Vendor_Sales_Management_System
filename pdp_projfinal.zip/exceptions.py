class InvalidPrice(Exception):
    pass

class InvalidQuantity(Exception):
    pass

class InvalidInput(Exception):
    pass

class ItemAlreadyExists(Exception):
    pass

class VegetableDoesNotExist(Exception):
    pass

class ItemNotFound(Exception):
    pass