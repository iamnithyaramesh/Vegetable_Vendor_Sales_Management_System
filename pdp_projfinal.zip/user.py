import re

def validate_password(password):
        """Validate the format of a password."""
        pattern = r"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
        match = re.match(pattern, password)
        return bool(match)

def validate_email1(email):
    """Validate a standard email address."""
    if email is None:
        return False
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    match = re.match(pattern, email)
    return bool(match)

def validate_email2(email):
    """Validate a standard ssn email address."""
    if email is None:
        return False
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9.-]+\.[a-zA-Z0-9.-]+$"
    match = re.match(pattern, email)
    return bool(match)

class User:
    
    def __init__(self, name, email, password):
        """Initialize a User object with name, email, and password."""
        self.name = name
        self.email = email
        self.password = password

    def change_details(self):
            """Change user details based on user input."""
            user_menu = int(input("Enter 1 to Change name\nEnter 2 to change email address\nEnter 3 to change Address\nEnter 4 to change password\nEnter your choice: "))
            if user_menu == 1:
                new_n = input("Enter new name: ")
                self.name = new_n
                print('Name has been updated!\n')
            elif user_menu == 2:
                while True:
                    email = input('Enter your email address: ')
                    if email != '':
                        if validate_email1(email) or validate_email2(email):
                            self.email = email
                            print('Email has been updated!\n')
                            break
                        else:
                            print('E-mail is invalid. Please use a valid e-mail.') 
                
            elif user_menu == 3:
                new_address = input("Enter new address: ")
                self.address = new_address
                print('Address has been updated!\n')
            elif user_menu == 4:
                new_password = input('Enter new password: ')
                while True:
                    if validate_password(new_password) == False:
                        print("Re-enter new password.")
                        new_password = input("Enter new password: ")
                    else:
                        print('Password has been updated!\n')
                        break
            else:
                pass   