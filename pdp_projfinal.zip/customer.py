from functions import *
from bill import Bill
from cart import Cart
from inventory import Inventory
from vegetable import Vegetable
from user import User
from exceptions import *
from datetime import datetime
from typing import Iterable, Iterator
from tabulate import *
from pickle import *

class Customer(User):
    def __init__(self, name, email, address, password):
        """
        Constructor for the Customer class.

        Parameters:
        - name: str, representing the name of the customer.
        - email: str, representing the email address of the customer.
        - address: str, representing the address of the customer.
        - password: str, representing the password of the customer.
        """
        super().__init__(name=name, email=email, password=password)
        self.address = address
        self.cart = None
        self.order_history = {}

    def place_order(self, user=None, lst=None):
        """
        Places an order for vegetables based on user input.

        Parameters:
        - user: User object, representing the user placing the order.
        - lst: List of Vegetable objects, representing the available vegetables.

        Returns:
        - Cart: The shopping cart containing the items ordered.
        """
        if any(item.stock > 0 for item in lst):
            c = Cart(user=user)
            self.cart = c
            inventory = Inventory()
            self.order_history[c.order_no] = datetime.now().strftime("%d/%m/%y")
            option = 'Yes'
            while True:
                item_name = input('Enter the name of the vegetable that you want to order: ')
                address = inventory.find_item_address(item_name)
                if address:
                    if address._category == 'Greens':
                        qty = int(input('Enter the number of bunch you want to buy: '))
                    elif address._category == 'Vegetable':
                        qty = int(input(f'Enter the grams (1 kilogram = 1000 grams) of {address._name.title()} you want to buy: '))
                    c.set_item(address, qty)
                    break
                else:
                    print('Vegetable does not exist in available vegetables. Please retry.')

            while True:
                option = input('Do you wish to add more items? [Yes/No]: ').lower()
                try:
                    if option == 'yes':
                        while True:
                            item_name = input('Enter the name of the vegetable that you want to order: ')
                            address = inventory.find_item_address(item_name)
                            if address:
                                if address._category == 'Greens':
                                    qty = int(input('Enter the number of bunch you want to buy: '))
                                elif address._category == 'Vegetable':
                                    qty = int(input(f'Enter the grams (1 kilogram = 1000 grams) of {address._name.title()} you want to buy: '))
                                c.set_item(address, qty)
                                break
                            else:
                                print('Vegetable does not exist in available vegetables. Please retry.')
                    elif option == 'no':
                        print('Proceeding to checkout...')
                        return self.checkout()
                    else:
                        print('Enter a valid input.')
                except InvalidQuantity as e:
                    print(e)
        else:
            print('The store ran out of supplies... Visit us later!')
            return None

    def checkout(self):
        """
        Handles the checkout process, taking UPI ID and PIN, and creating a receipt.

        Returns:
        - Cart: The shopping cart containing the items ordered.
        """
        b = Bill(self.cart)
        b.create_receipt()
        while True:
            upi = input('Enter your UPI ID: ')
            if validate_upi(upi):
                while True:
                    pin = input('Enter your 6-digit PIN: ')
                    if 6 >= len(pin) > 5 and pin.isnumeric():
                        print('Your order has been placed!')
                        break
                    else:
                        print('Enter a valid PIN number!')
                break
            else:
                print('Invalid UPI ID, try again.')
        # notif push
        return self.cart

    def notify(self, cart):
        """
        Placeholder method for future notification functionality.

        Parameters:
        - cart: Cart object, representing the shopping cart.

        Returns:
        - None
        """
        pass

    def view_order_history(self):
        """
        Displays the order history of the customer.

        Returns:
        - None
        """
        item_index = 0
        for i in self.order_history:
            item_index += 1
            print(f"Order Number:", i, "Placed On", self.order_history[i])
        if item_index == 0:
            print('No items found.')

    def view_available_items(self):
        """
        Displays all available items in the inventory.

        Returns:
        - None
        """
        inventory_instance = Inventory()
        print(inventory_instance.view_all_items())

    def view_details(self):
        """
        Displays the details of the customer.

        Returns:
        - None
        """
        print(f'Name: {self.name}\n',
              f'Address: {self.address}\n',
              f'Email: {self.email}')

if __name__ == '__main__':
    C = Customer('A', '1', '5, Park road', 'efnif')
    C.place_order()
