from user import User
from datetime import datetime, timedelta
from exceptions import *


class Vendor(User):
    def __init__(self, name, password, email, inventory):
        """
        Constructor for Vendor class.

        Parameters:
        - name (str): Vendor's name.
        - password (str): Vendor's password.
        - email (str): Vendor's email address.
        - inventory (Inventory): Vendor's inventory.

        Attributes:
        - order_list (list): List to store orders.
        - processed_orders (list): List to store processed orders.
        """
        super().__init__(name=name, password=password, email=email)
        self.inventory = inventory
        self.order_list = []
        self.processed_orders = []

    def change_inventory(self):
        """
        Change the details of a vegetable in the inventory.
        Takes user input for the vegetable name to be updated.
        """
        item_name = input('Enter the name of the vegetable that you want to update: ')
        self.inventory.update_item(item_name)

    def add_order(self, cart):
        """
        Add a new order to the vendor's order list.

        Parameters:
        - cart (Cart): Cart containing the ordered items.
        """
        self.order_list.append(cart)

    def update_picks(self):
        """
        Update today's picks by adding vegetables to the inventory.
        Takes user input for the vegetable name to be added.
        """
        while True:
            try:
                item_name = input(f'Enter the name of the vegetable to be added to {datetime.today().date()} picks: ')
                self.inventory.update_today_picks(item_name)
                exit_opt = input('Do you wish to add more vegetables? [Yes/No]: ')
                if exit_opt.lower() == 'yes':
                    pass
                elif exit_opt.lower() == 'no':
                    break
                else:
                    print('Enter either Yes or No.')
            except ItemNotFound as e:
                print(e)

    def remove_picks(self):
        """
        Remove vegetables from today's picks in the inventory.
        Takes user input for the vegetable name to be removed.
        """
        while True:
            try:
                item_name = input(f'Enter the name of the vegetable to be removed from {datetime.today().date()} picks: ')
                self.inventory.remove_todays_picks(item_name)
                exit_opt = input('Do you wish to remove more vegetables? [Yes/No]: ')
                if exit_opt.lower() == 'yes':
                    pass
                elif exit_opt.lower() == 'no':
                    break
                else:
                    print('Enter either Yes or No.')
            except ItemNotFound as e:
                print(e)

    def view_order(self, c=None):
        """
        Display details of a specific order.

        Parameters:
        - c (Cart): Cart object representing the order. If None, uses the first order in the order list.
        """
        if c is None:
            if len(self.order_list) > 0:
                c = self.order_list[0]
            else:
                print('No orders pending.')
                return None
        print(f'Order number: {c.order_no}')
        print('Customer details:')
        c.user.view_details()
        for item, qty in c.cart.items():
            unit = 'g' if item._category == 'Vegetable' else ' bunch'
            print('Vegetable: ', item._name)
            print('Quantity: ', str(qty) + unit)
            print()

    def view_orders(self):
        """Display details of all orders in the order list."""
        for order in self.order_list:
            self.view_order(order)
            print()

    def process_order(self):
        """
        Process the first order in the order list.
        Takes user input to confirm order processing and expected delivery time.
        Returns details of the processed order.
        """
        if not self.order_list:
            print("No orders to process.")
            return

        c1 = self.order_list[0]
        self.view_order(c1)

        while True:
            ip = input("Has the order been processed? (Yes/No): ").lower()
            if ip == 'yes':
                try:
                    time = int(input("Enter the expected delivery time in minutes: "))
                    delv_time = datetime.now() + timedelta(minutes=time)
                    details = (self.order_list[0].user.email, self.order_list[0].user.name, delv_time.strftime('%Y-%m-%d %H:%M'), self.order_list[0].calc_price())
                    self.processed_orders.append(self.remove_order(self.order_list))
                    #print("\nprocessed: ", self.processed_orders)
                    #print("\norders: ", self.order_list)
                    print(f"Order processed. Expected delivery time: {delv_time}")
                    return details
                except ValueError:
                    print("Please enter a valid integer for time.")
                break
            elif ip == 'no':
                print("Order not processed.")
                break
            else:
                print('Enter either yes or no.')

    def remove_order(self, lst):
        """
        Remove the first order from the order list and return it.

        Parameters:
        - lst (list): List of orders (Cart objects).

        Returns:
        - Cart: The removed order.
        """
        return lst.pop(0)
