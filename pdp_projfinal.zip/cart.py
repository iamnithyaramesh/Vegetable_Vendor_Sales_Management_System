from vegetable import *

class InvalidQuantity(Exception):
    pass

class OrderNumberGenerator:
    _instance = None

    def __new__(cls):
        """
        Creates a new instance of OrderNumberGenerator if it doesn't exist.

        Returns:
        - OrderNumberGenerator: The instance of the OrderNumberGenerator.
        """
        if not cls._instance:
            cls._instance = super(OrderNumberGenerator, cls).__new__(cls)
            cls._instance._current_number = 100000 
        return cls._instance

    def __iter__(self):
        """
        Makes the class iterable.

        Returns:
        - OrderNumberGenerator: The instance of the OrderNumberGenerator.
        """
        return self

    def __next__(self):
        """
        Generates the next order number.

        Returns:
        - int: The next order number.
        """
        if self._current_number >= 1000000:
            raise StopIteration
        else:
            self._current_number += 1
            return self._current_number - 1

class Cart:
    g = OrderNumberGenerator()

    def __init__(self, user=None, order_no=None):
        """
        Constructor for the Cart class.

        Parameters:
        - user: User object, representing the user placing the order.
        - order_no: int, representing the order number.
        """
        self.user = user
        self.order_no = next(Cart.g)
        self.cart = {}
    
    def calc_price(self):
        """
        Calculates the total price of items in the cart based on their quantity and price.

        Returns:
        - float: Total price of items in the cart.
        """
        sum = 0
        for item, qty in self.cart.items():
            if item._category == 'Vegetable':
                sum += qty / 100 * item._price
            else:
                sum += qty * item._price
        return sum

    def set_item(self, item, qty=1):
        """
        Adds an item to the cart with the specified quantity.

        Parameters:
        - item: Vegetable object, representing the item to be added.
        - qty: int, representing the quantity of the item to be added.

        Raises:
        - InvalidQuantity: If the quantity is not within the valid bounds.

        Returns:
        - None
        """
        if 0 < qty <= item._stock:
            self.cart[item] = qty
            item._stock -= qty
        else:
            raise InvalidQuantity('Enter a quantity within the bounds of zero to stock available. Please retry!')

if __name__ == '__main__':
    
    c1 = Cart()
    carrot = Vegetable(name="Carrot", price=1.50, stock=5)
    tomato = Vegetable(name="Tomato", price=2.00, stock=8)
    broccoli = Vegetable(name="Broccoli", price=3.00, stock=6)
    spinach = Vegetable(name="Spinach", price=1.75, stock=9)
    onion = Vegetable(name="Onion", price=1.25, stock=7)

    c1.set_item(carrot, 3)
    c1.set_item(tomato, 5)

    # Print the cart items
    for item, qty in c1.cart.items():
        print(f"{item._name}: {qty}")
    
    print(c1.order_no)

    c2 = Cart()
    carrot = Vegetable(name="Carrot", price=1.50, stock=5)
    tomato = Vegetable(name="Tomato", price=2.00, stock=8)
    broccoli = Vegetable(name="Broccoli", price=3.00, stock=6)
    spinach = Vegetable(name="Spinach", price=1.75, stock=9)
    onion = Vegetable(name="Onion", price=1.25, stock=7)

    c2.set_item(broccoli, 3)
    c2.set_item(tomato, 5)
    print(tomato._stock)

    # Print the cart items
    for item, qty in c2.cart.items():
        print(f"{item._name}: {qty}")
    
    print(c2.order_no)

    c3 = Cart()
    carrot = Vegetable(name="Carrot", price=1.50, stock=5)
    tomato = Vegetable(name="Tomato", price=2.00, stock=8)
    broccoli = Vegetable(name="Broccoli", price=3.00, stock=6)
    spinach = Vegetable(name="Spinach", price=1.75, stock=9)
    onion = Vegetable(name="Onion", price=1.25, stock=7)

    c3.set_item(broccoli, 3)
    c3.set_item(tomato, 5)

    # Print the cart items
    for item, qty in c3.cart.items():
        print(f"{item._name}: {qty}")
    
    print(c3.order_no)
    print(c3.calc_price())
